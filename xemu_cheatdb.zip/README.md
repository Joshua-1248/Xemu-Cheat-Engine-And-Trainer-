# Xemu cheat database — cheats and patches split out of the INI

The cheats and patches that were embedded as JSON inside
`xemu_cheat_manager.ini` are now one `.txt` per game, named PCSX2-pnach style.

```
cheats/                8 files
patches/               1 file
_source/               9 lossless JSON sidecars — the exact trees from the INI
add_titleids.py        one-time setup: add titleid/serial keys to your INI
verify_cheatdb.py      standalone "did anything get lost?" checker
restore_ini.py         rebuild the INI from the sidecars
titleid_map.csv        all 736 INI games -> serial + title id
```

The trainer picks these up automatically — see **Auto-discovery** below.

Nothing was invented and nothing was dropped. All 80 cheats and all 140 raw
`(cmd, val)` pairs came out of the INI and parse back identically. Run
`python3 verify_cheatdb.py` any time to confirm it — see below.

---

## Naming

`SERIAL_TITLEID.txt`, e.g. `MS-100_4D530064.txt`.

The two parts are not independent — the hex title id *is* the serial:

```
MS-100  ->  'M'=0x4D  'S'=0x53  100=0x0064  ->  4D530064
AC-001  ->  'A'=0x41  'C'=0x43  001=0x0001  ->  41430001
ZD-004  ->  'Z'=0x5A  'D'=0x44  004=0x0004  ->  5A440004
```

Both of the examples given check out against the database, and the rule holds
for all 2,179 entries in it with zero exceptions — so the filename is
self-checking. If the two halves ever disagree, the name is wrong.

Title ids came from [MobCat's OG Xbox game
list](https://github.com/MobCat/MobCats-original-xbox-game-list) (dbox.tools
blocks automated requests). Matching was done on the redump-style base title
with region-overlap scoring; 685 of 736 INI entries resolved (93.1%). Every one
of the 9 files below was checked by hand.

| INI name | title | file |
|---|---|---|
| 007 - Agent Under Fire (USA) | 007 - Agent Under Fire | `cheats/EA-013_4541000D.txt` |
| Conker - Live & Reloaded (USA) | Conker - Live & Reloaded | `cheats/MS-081_4D530051.txt` |
| Doom 3 - Collector's Edition (USA) | Doom 3 - Collector's Edition | `cheats/AV-032_41560020.txt` |
| Half-Life 2 (USA, Europe) | Half-Life 2 | `cheats/EA-145_45410091.txt` |
| Halo 2 (USA) | Halo 2 | `cheats/MS-100_4D530064.txt` |
| Halo 2 (USA) | Halo 2 | `patches/MS-100_4D530064.txt` |
| Halo: Combat Evolved (USA) | Halo: Combat Evolved | `cheats/MS-004_4D530004.txt` |
| Max Payne (USA) | Max Payne | `cheats/TT-003_54540003.txt` |
| Return To Castle Wolfenstein: Tides of War (USA) | Return To Castle Wolfenstein: Tides of War | `cheats/AV-016_41560010.txt` |

**Doom 3 - Collector's Edition** was the only one the matcher could not resolve
automatically, and it is resolved by hand rather than by loosening the matcher.
The database treats the CE as a variant of base Doom 3, not a separate title —
both carry AV-032 / `41560020`. So the CE and the plain `Doom 3 (USA)` entry in
the INI share one title id. Only the CE has cheats, so there is no file
collision today, but adding cheats to plain Doom 3 later would land in the same
file.

`//game=` uses the INI name with region suffixes stripped, **not** the
database's `Title_Name`. That column holds the XBE's internal marketing string
and is often abbreviated or malformed: `Wolfenstein`, `Half - Life 2`,
`Agent Under Fire ™`, and just `Halo` for Halo: Combat Evolved. The INI names
are the ones you wrote and they keep edition distinctions.

---

## File format

The body is the trainer's existing `.cht` grammar, so `parse_file()` reads
these with no changes. Everything the grammar has no slot for goes on `//`
lines, which the parser skips entirely — it only reads `;` comments directly
above a block and code lines inside `{ }`.

```
//game=Halo 2
//serial=MS-100
//titleid=4D530064
//kind=cheats

//group=Single Player\Infinite\Ammo

//enabled=1
; Author: Josh_7774
[Single Player\Infinite\Shields (Alternate)] {
  62D86098 7F7FFFFF
  00020001 000000F0
}
```

| Line | Why it exists |
|---|---|
| `//game=` | as requested |
| `//serial=` `//titleid=` | file self-identifies even if renamed |
| `//kind=` | tells a `cheats/` file from a `patches/` one out of context |
| `//enabled=` | **`.cht` has no enabled field.** `make_cheat()` defaults to `enabled=False`, so without this every cheat would come back off |
| `//group=` | **`.cht` cannot represent an empty group.** Groups only exist implicitly as path components of a cheat, so a group with no cheats in it vanishes |

There are 13 empty groups in the INI — `Driving/On-Rails`, `Have`,
`Single Player\Infinite\Ammo`, and ten placeholder weapon groups under RTCW's
`Cooperative` branch. They are recorded on `//group=` lines so nothing is
silently dropped.

Order matters in the header block: `//enabled=` goes *above* the `; Author:`
line, because the parser's comment group only matches `;` lines immediately
preceding the `[`. A `//` line in between would break author/description
capture.

---

## One bug found, and it is not new

Four cheats would not survive the move, and they were already not surviving.

Halo 2 and Half-Life 2 both have a group literally named `[ASM]`, so an
exported block header looks like:

```
[[ASM]\Infinite Ammo - No Reload [ASM]] {
```

The block-name pattern was `\[([^\]\n]*)\]` — a character class that excludes
`]`, so it cannot span a name containing brackets. The match fails and the
whole block is skipped, silently.

This is **pre-existing**, not caused by the split into files. Confirmed against
the unmodified trainer: run its own `_cht_blocks()` export and feed the result
straight back to `parse_text()` and you get 7 cheats in, 6 out. Anyone who ever
exported a `.cht` and re-imported it has been losing these.

The fix is one character class, in `parse_text`:

```python
r'\[([^\]\n]*)\]\s*\{\s*(.*?)\s*\}'     # before
r'\[([^\n]*)\]\s*\{\s*(.*?)\s*\}'       # after
```

Greedy matching then backtracks to the last `]` before the `{`, which is
correct because a block name cannot contain a newline anyway.

Regression-tested against the original on eleven inputs — plain blocks, group
paths, author/description comments, forward-slash separators, multiple blocks,
inline braces, empty bodies, comments inside bodies, and surrounding junk text.
**Identical results on all nine normal cases**; behaviour changes only on the
two bracket-in-name cases, which previously returned nothing.

Applied in `xemu_trainer_lib/codes.py`. It is the only intentional behaviour
change to the split package — everything else there is still a byte-identical
move.

Without the fix: 76 of 80 cheats survive. With it: 80 of 80.

---

## Nothing is lost — and you can prove it yourself

```
cd cheatdb
python3 verify_cheatdb.py
```

```
cheat entries : 80 of 80
code pairs    : 140 of 140
RESULT: PASS - every code accounted for
```

`verify_cheatdb.py` is standalone. It carries its own copy of the `.cht`
grammar and does not import the trainer, so it does not care which version you
have installed. It parses every `.txt` **twice** — once with the original block
pattern and once with the corrected one — and tells you which files depend on
the fix and exactly which entries would be skipped without it. Exit code 0 means
nothing is missing.

### Three independent copies of the data

1. **`xemu_cheat_manager.ini`** — untouched. Every code is still in it.
2. **`_source/*.json`** — the exact tree per game, straight from the INI,
   verbatim. If every text parser broke tomorrow, the data is still here.
3. **`cheats/` and `patches/`** — the working text files.

`restore_ini.py` rebuilds an INI from the sidecars:

```
python3 restore_ini.py path/to/xemu_cheat_manager.ini
```

It writes `<ini>.restored` and never overwrites your file. Tested: INI →
sidecars → INI comes back **exact**, 140 code pairs in, 140 out, zero
differences across all 9 games.

### Full audit

Run against the INI adversarially rather than confirmatorily — looking for data
in places I had not checked, not just re-confirming what I had:

| Check | Result |
|---|---|
| Sections outside `[game:*]` holding codes | none (only `[main]`) |
| Keys in game sections beyond `path`/`cheats`/`patches` | none |
| Non-empty `path` fields pointing at external cheat files | none |
| Stray hex-pair lines in the raw INI text | 0 |
| Cheat leaves | 80 in INI, 80 in files |
| Raw `(cmd, val)` pairs | 140 in INI, 140 in files |
| Groups (incl. 13 empty) | 44 in INI, 44 accounted for |
| Per-leaf `codes`, `desc`, `author`, `enabled` | all match |
| Serial ↔ title id encoding rule | 2,179/2,179 consistent |
| Regex fix vs original on normal inputs | identical on all 9 |

### Characters that are safe in cheat and group names

Checked with the corrected parser, since you will be adding more cheats:

| Safe | |
|---|---|
| `[` `]` | brackets — **only** with the fix applied |
| `{` `}` | braces |
| `;` | semicolons, including leading |
| `( )` `#` `'` `:` `.` `&` `%` | punctuation |
| `™` and other non-ASCII | files are UTF-8 |

`/` and `\` are **group separators**, not literal characters — `A/B` becomes a
group `A` containing `B`. That is by design, not a bug.

---

## Auto-discovery — how the trainer finds these

Both folders sit beside the INI and are scanned **independently**. A game can
have a cheats file, a patches file, both, or neither. There is no single `path`
field involved anywhere.

```
<wherever you launch from>/
    xemu_cheats_trainer.py
    xemu_trainer_lib/
    xemu_cheat_manager.ini
    cheats/      MS-100_4D530064.txt, ...
    patches/     MS-100_4D530064.txt
```

`Config.FILE` is a relative name, so it resolves against the current working
directory. `Config.base_dir()` anchors on its **absolute** path, so the folders
are always found next to the INI no matter which directory you launch from.

### Setup

```
python3 add_titleids.py path/to/xemu_cheat_manager.ini
```

Writes `<ini>.new`; check it and rename over your INI. It adds a `titleid` and
`serial` key per game and touches nothing else — verified: 736 sections, zero
existing values changed, 140 code pairs before and after.

That's the whole setup. A game with a title id loads from its files; a game
without one loads from the INI JSON exactly as it always did, so this is
backwards compatible with any database.

### What loading does, precisely

- A file, when present, is **authoritative** — including its enabled flags,
  which are read verbatim. **Loading never turns a cheat on or off.**
- Order, nesting, empty groups, collapsed groups, descriptions and authors all
  survive, because groups and cheats are written interleaved in tree order and
  the reader simply replays the file top to bottom.
- If a file is missing or fails to parse, that game keeps whatever the INI
  holds. A bad file cannot wipe a game.

### What saving does

- The `.txt` files are written **first**, then the INI. If the process dies
  between the two, the INI is merely stale, never wrong.
- Writes are atomic — temp file then rename — so a crash cannot truncate one.
- Enabled flags go out exactly as they are in memory. Nothing normalises,
  defaults, or flips them.
- The INI keeps a **full JSON mirror** of every game. It stays a complete
  standalone backup, so there are still three independent copies of the data.
- A game emptied in the UI has its file removed, so it doesn't reappear on the
  next load.

### Shared title IDs

Six title IDs are claimed by two game sections each — Doom 3 and Doom 3
Collector's Edition both report AV-032, Ghost Recon appears twice under two
names, and so on. Two sections pointing at one file is the single way this
scheme could lose data, so it is prevented in two places:

1. `add_titleids.py` gives the key to only one section per title id — the one
   holding actual cheats. The other keeps loading from its INI JSON.
2. `Config.save` decides file ownership in a pre-pass **before touching
   anything**, and a section holding cheats always beats an empty one.

The second layer matters: an earlier first-come-first-served version let an
empty section claim the path and delete a file whose cheats belonged to the
other section. Now tested directly — with the collision recreated by hand and
the empty section listed first, the file survives byte-identical and the CE's
cheats reload intact.

### Verified

| Check | Result |
|---|---|
| Loads from files, not the INI | INI JSON for Halo 2 emptied, file left → 7 cheats still loaded |
| Content after load | 9 games, 80 cheats, 64 enabled — matches source exactly |
| Save rewrites files | byte-identical, no drift |
| load → save → load | fixed point, identical |
| Enabled flags changed by a cycle | 0 of 80 |
| Enabled flags vs the original INI | 80 checked, 0 mismatched |
| Toggle all 7 Halo 2 cheats, save, reload | every flip persisted |
| Toggle back, save, reload | exactly the original state |
| Empty section colliding on a title id | file survives, cheats intact |
| Games with no title id | 57, all still load from INI |

### Two more name bugs found on the way

Both were live in the existing data, and both are fixed in `cheatfiles.py`:

- **`Driving/On-Rails`** — a group in 007 Agent Under Fire whose name contains a
  literal `/`. The legacy grammar treats `/` as a path separator, so it silently
  became two nested groups, `Driving` containing `On-Rails`. This format splits
  on `\` only, with `\\` for a literal backslash, so the name round-trips.
- **DOTALL vs `.`** — my first combined scanner used `.` on the `//group=`
  line while `re.DOTALL` was on for the code body, so one directive swallowed
  the rest of the file. Caught by the round-trip test, not by inspection.


## Still left alone

- **No empty files for the other 727 games.** PCSX2 only ships a pnach where
  there is something to patch. `titleid_map.csv` has serials for all 736, so
  scaffolding more is a one-liner whenever you want it.
- **The INI keeps a full JSON mirror.** Nothing is deleted from it. It stays a
  complete standalone backup even after auto-discovery takes over.
- **51 unresolved names** — listed in the CSV with an empty `title_id`. Mostly
  Europe- or Japan-only releases, plus a few that are not original Xbox titles
  (`Master Chief Collection`). None have cheats. They load from the INI.
